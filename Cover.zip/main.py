import os
try:
    from gp.c import circle_image , img_make , resize_image, crop_img
    from gp.addtext import addT, center_text
    from gp.over import over
    
except ImportError:
    os.system("pip install -r requirements.txt")
    

# get img size fanc
def get_image_size(imgsize):
    with Image.open(imgsize) as img:
        return img.size


def cover1():
	# requerments Path
	mainP = input("Enter Image Path: ") #image.jpg"
	img_make("img/bg.jpg",(1280,720),"pink")
	bg  = "img/bg.jpg"
	font = "f/arial.ttf"
	sur = "f/sur.ttf"
	out1 = "img/output.png"
	out2 = "img/output2.png"
	mask = "mask.png"
	# size & position & color & text
	position = (100, 100)    # x,y
	red =  (255, 0, 0, 255)    # red
	color = red
	
	
	# cover try 1 
	
	#crop_rectangle = (100, 100, 400, 400)
	crop_img(mainP,"img/ava.jpg")
	ab="img/ava.jpg"
	cv = over(bg,out1,img1=ab,position1=(int((1280/4)-290),125), img2=mask, position2=(0,0))
	
	name = input("Enter your first Name: ") #"Grandpa"
	name = name.upper()
	position = (700,250)
	addT(out1, name, "new.jpg", "white", position, "f/arial.ttf", size=100)
	slog = input("Enter Your last name :") # "EJ"
	#slogan = slog.upper()
	position = (780,330)
	addT("new.jpg", slog, "new.jpg", color,position, font_path="f/sur.ttf", size=100)
	slog = input("Enter Motivation Line :") #"if you try Hard , you can do anything "
	position =(700,499)
	addT("new.jpg", slog, "new.jpg", "white",position, font_path=font, size=30)
	


cover1()
os.system("rm -rf img/*")