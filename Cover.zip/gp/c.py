from PIL import Image, ImageDraw,ImageColor

#new 2d image make 
def img_make(output_path, size=(1280, 720), bg_color="black"):
    # Convert the color name to RGB
    rgb_color = ImageColor.getrgb(bg_color)
    
    # Create a new image with the specified size and background color
    image = Image.new("RGB", size, color=rgb_color)
    
    # Save the image to the specified output path
    image.save(output_path, format="JPEG")
    
# resize image fanc
def resize_image(input_path, output_path, size=(200, 200)):
    with Image.open(input_path) as img:
        resized_image = img.resize(size, Image.LANCZOS)
        #save as a png format
        resized_image.save(output_path, format="PNG")
    
    

def circle_image(image_path, output_path):
    # open & convert with RGBA
    image = Image.open(image_path).convert("RGBA")
    
    # new image make 
    size = (min(image.size),) * 2
    mask = Image.new('L', size, 0)
    draw = ImageDraw.Draw(mask)
    
    # make circle mask 
    draw.ellipse((0, 0) + size, fill=255)
    
    # new image crop
    image = image.crop(((image.size[0] - size[0]) // 2, (image.size[1] - size[1]) // 2, 
                        (image.size[0] + size[0]) // 2, (image.size[1] + size[1]) // 2))
    image.putalpha(mask)

    # save as a png format
    image.save(output_path, format="PNG")
    
    
    



def crop_img(input_path, output_path, crop_size=(475, 475)):
    with Image.open(input_path) as img:
        # Get the original dimensions of the image
        width, height = img.size
        
        # Calculate the center of the image
        center_x, center_y = width // 2, height // 2
        
        # Calculate the crop box
        left = center_x - crop_size[0] // 2
        upper = center_y - crop_size[1] // 2
        right = center_x + crop_size[0] // 2
        lower = center_y + crop_size[1] // 2
        
        # Ensure the crop box is within the bounds of the image
        left = max(0, left)
        upper = max(0, upper)
        right = min(width, right)
        lower = min(height, lower)
        
        # Crop the image
        cropped_img = img.crop((left, upper, right, lower))
        
        # Save the cropped image
        cropped_img.save(output_path, format="JPEG")

# Example usage:
#input_image_path = "image.jpg"
#output_image_path = "cropped_image.jpg"

#crop_center(input_image_path, output_image_path)