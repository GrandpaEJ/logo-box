from PIL import Image

def over(bg_path,output_path, img1=None, position1=None, img2=None, position2=None, img3=None, position3=None, img4=None, position4=None, img5=None, position5=None):
    bg_image = Image.open(bg_path).convert("RGBA")
    
    if img1:
        image1 = Image.open(img1).convert("RGBA")
        bg_image.paste(image1, position1, mask=image1)
    
    if img2:
        image2 = Image.open(img2).convert("RGBA")
        bg_image.paste(image2, position2, mask=image2)
    
    if img3:
        image3 = Image.open(img3).convert("RGBA")
        bg_image.paste(image3, position3, mask=image3)
    
    if img4:
        image4 = Image.open(img4).convert("RGBA")
        bg_image.paste(image4, position4, mask=image4)
    
    if img5:
        image5 = Image.open(img5).convert("RGBA")
        bg_image.paste(image5, position5, mask=image5)
    bg_image = bg_image.convert("RGB")  
    bg_image.save(output_path, format="JPEG")
    
    

# Example usage:
#bg_path = 'bg.jpg'
#output_image = add_img_on_bg(bg_path, img1="output.png", position1=(100, 100), img2="image2.png", position2=(200, 200))
#output_image.save("black.png")  # Display the composed image