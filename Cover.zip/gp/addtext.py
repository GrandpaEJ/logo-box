from PIL import Image, ImageDraw, ImageFont

def addT(image_path, text, output_path, text_color, text_position=(50, 50), font_path="arial.ttf", size=40):
    try:
        image = Image.open(image_path).convert("RGBA")
    except Exception as e:
        print(f"Error opening image: {e}")
        return

    draw = ImageDraw.Draw(image)
    
    try:
        print(f"Trying to load font from path: {font_path}")
        font = ImageFont.truetype(font_path, size)
    except IOError as e:
        print(f"Error loading font: {e}")
        print("Using default font.")
        font = ImageFont.load_default()
    
    draw.text(text_position, text, font=font, fill=text_color)
    
    try:
        image.save(output_path, format="PNG")
        print(f"Image saved to {output_path}")
    except Exception as e:
        print(f"Error saving image: {e}")		
    
    
# addT(image_path="image.jpg" , text="your text", output_path="output.png" , text_color=(250,0,0,250), text_position=(x,y), font_size=60)





def center_text(bg_image_path, message,output_path,hight=300,font_path="arial.ttf", font_size=60, fontColor="pink"):
    # Load the background image
    bg_image = Image.open(bg_image_path).convert("RGBA")
    draw = ImageDraw.Draw(bg_image)
    
    # Load the font
    font = ImageFont.truetype(font_path, font_size)
    
    # Calculate text size
    _, _, text_width, text_height = draw.textbbox((0, 0), message, font=font)
    
    # Calculate the position for the text to be centered
    W, H = bg_image.size
    x = (W - text_width) / 2
    y = (hight)
    
    # Draw the text onto the image
    draw.text((x, y), message, font=font, fill=fontColor)
    
    # Save the resulting image
    bg_image.save(output_path, "PNG")

# Example usage
#center_text(
#    bg_image_path="bg.jpg",
#    message="Welcome",
#    output_path="output.png",
#    font_path="arial.ttf",
#    font_size=50,
#    fontColor="green"
#    
#)